#Sibyl

Sibyl from [Startup.ML](http://startup.ml) is an anomaly detection tool optimized for high-dimensional, heterogeneous (both categorical and continuous) datasets.   Its time complexity is near linear and space complexity is quadratic to the number of dimensions.

## Overview

- __Real-World Dataset:__

- __Performance:__

- __Enrichment:__

## License

Please review the [license terms](https://raw.githubusercontent.com/startupml/sibyl/master/LICENSE.txt?token=AJUKypG9bJUtJ5lSIVYiLpdY3RbLHis2ks5WVd6ywA%3D%3D) before using and installing Sibyl.

## Getting started

## Installation
