## Anomaly Detection in High Dimensional Heterogeneous Datasets

It can work with numberical / mixed datasets as well. But numberical attributes need to be discretized first.

Compatible with Python 2.7
